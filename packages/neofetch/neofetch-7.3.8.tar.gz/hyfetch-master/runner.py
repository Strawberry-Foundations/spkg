#!/usr/bin/env python3

import hyfetch

if __name__ == '__main__':
    hyfetch.main.run()

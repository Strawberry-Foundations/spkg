---
name: Content Request
about: Suggest supporting new flags, distros, package managers, etc.
title: ''
labels: 'content-request'
assignees: ''

---

### Describe the content
Describe the content you would like to see added to HyFetch.

### Links
Please include relevant links to the content.

e.g. For distros, include a link to the distro's official website, download link, or development repository.

### Additional context
Add any other context about the problem here.

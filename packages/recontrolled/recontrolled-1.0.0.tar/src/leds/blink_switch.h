#ifndef BLINK_SWITCH_H
#define BLINK_SWITCH_H

int blink_switch();

#endif
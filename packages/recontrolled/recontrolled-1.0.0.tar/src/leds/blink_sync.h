#ifndef BLINK_SYNC_H
#define BLINK_SYNC_H

int blink_sync();

#endif
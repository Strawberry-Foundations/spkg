#define RED_LED "/sys/class/leds/led1/brightness"
#define GREEN_LED "/sys/class/leds/led0/brightness"
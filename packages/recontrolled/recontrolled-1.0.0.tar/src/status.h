#ifndef STATUS_H
#define STATUS_H

int status();
int check_red();
int check_green();

#endif

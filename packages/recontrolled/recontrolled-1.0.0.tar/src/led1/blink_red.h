#ifndef BLINK_RED_H
#define BLINK_RED_H

int blink_red();

#endif
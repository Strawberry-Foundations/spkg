#ifndef DEACTIVATE_RED_H
#define DEACTIVATE_RED_H

int deactivate_red();

#endif
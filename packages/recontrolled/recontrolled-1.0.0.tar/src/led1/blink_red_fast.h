#ifndef BLINK_RED_FAST_H
#define BLINK_RED_FAST_H

int blink_red_fast();

#endif
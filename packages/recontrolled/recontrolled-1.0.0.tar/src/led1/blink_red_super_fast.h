#ifndef BLINK_RED_SUPER_FAST_H
#define BLINK_RED_SUPER_FAST_H

int blink_red_super_fast();

#endif
#ifndef BLINK_RED_SLOW_H
#define BLINK_RED_SLOW_H

int blink_red_slow();

#endif
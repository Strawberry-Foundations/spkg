#ifndef DEACTIVATE_GREEN_H
#define DEACTIVATE_GREEN_H

int deactivate_green();

#endif
#ifndef BLINK_GREEN_FAST_H
#define BLINK_GREEN_FAST_H

int blink_green_fast();

#endif
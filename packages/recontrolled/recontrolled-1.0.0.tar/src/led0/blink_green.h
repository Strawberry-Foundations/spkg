#ifndef BLINK_GREEN_H
#define BLINK_GREEN_H

int blink_green();

#endif
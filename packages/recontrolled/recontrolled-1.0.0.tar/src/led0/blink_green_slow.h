#ifndef BLINK_GREEN_SLOW_H
#define BLINK_GREEN_SLOW_H

int blink_green_slow();

#endif
#ifndef BLINK_GREEN_SUPER_FAST_H
#define BLINK_RED_SUPER_FAST_H

int blink_green_super_fast();

#endif
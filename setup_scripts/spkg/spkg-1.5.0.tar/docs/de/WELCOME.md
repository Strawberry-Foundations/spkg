# Advanced Source Package Managment
Willkommen zu den offiziellen Dokumentationen zu den Paketmanager "spkg". Hier erfährst du, wie spkg funktioniert, wie man es (korrekt) installiert, wie man Pakete einreichen kann oder auch selber entwickeln kann für spkg. 

# Inhaltsverzeichnis
* [Installation](https://github.com/Salware-Foundations/spkg/blob/main/docs/de/INSTALLATION.md)
* [Pakete einreichen](https://github.com/Salware-Foundations/spkg/blob/main/docs/de/SUBMIT_PACKAGE.md)
* [Plugins entwickeln](https://github.com/Salware-Foundations)
* [Das Backend von spkg](https://github.com/Salware-Foundations)
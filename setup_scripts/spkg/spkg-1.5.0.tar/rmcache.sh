#!/bin/bash
sudo rm -rf __pycache__/; sudo rm -rf plugins/__pycache__; sudo rm -rf src/__pycache__
